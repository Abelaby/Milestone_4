package com.kral.productmanagement.productdescription;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductdescriptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
