package com.kral.productmanagement.productdescription.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kral.productmanagement.productdescription.model.ProductDescription;
import com.kral.productmanagement.productdescription.service.ProductDescriptionService;
import com.kral.productmanagement.productdescription.service.ProductDescriptionServiceImpl;

@RestController
@RequestMapping("productDescription")
public class ProductDescriptionController {
	
	@Autowired
	private ProductDescriptionService productDescriptionService;
	
	@GetMapping("byid/{productdescriptionid")
	public ProductDescription getDescriptionById(@PathVariable Integer productdescriptionid) {
		return productDescriptionService.productDescriptionById(productdescriptionid);
	}
	
	@PostMapping
	public ProductDescription createDescription(@RequestBody ProductDescription productDescription) {
		return productDescriptionService.postProduct(productDescription);
	}
	
	
	
}
