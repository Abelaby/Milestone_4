package com.kral.productmanagement.productdescription.service;

import com.kral.productmanagement.productdescription.model.ProductDescription;

public interface ProductDescriptionService {
	ProductDescription productDescriptionById(Integer productDescriptionId);
	ProductDescription postProduct(ProductDescription productDescription);

}
