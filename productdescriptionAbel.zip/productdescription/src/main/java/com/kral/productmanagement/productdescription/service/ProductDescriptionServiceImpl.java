package com.kral.productmanagement.productdescription.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kral.productmanagement.productdescription.model.ProductDescription;
import com.kral.productmanagement.productdescription.repository.ProductDescriptionRepository;

@Service

public class ProductDescriptionServiceImpl implements ProductDescriptionService {
	
	@Autowired
	private ProductDescriptionRepository productDescriptionRepository;
	

	@Override
	public ProductDescription productDescriptionById(Integer productDescriptionId) {
		return productDescriptionRepository.findById(productDescriptionId).orElseThrow();
	}

	@Override
	public ProductDescription postProduct(ProductDescription productDescription) {
		return productDescriptionRepository.save(productDescription);
	}

}
