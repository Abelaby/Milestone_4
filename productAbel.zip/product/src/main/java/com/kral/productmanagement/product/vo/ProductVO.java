package com.kral.productmanagement.product.vo;

import com.kral.productmanagement.product.model.Product;
//
//import lombok.Data;
//
//@Data
public class ProductVO {
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public DescriptionVO getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(DescriptionVO productDescription) {
		this.productDescription = productDescription;
	}
	private Product product;
	private DescriptionVO productDescription;
}
