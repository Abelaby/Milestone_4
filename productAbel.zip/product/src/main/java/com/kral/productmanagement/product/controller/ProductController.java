package com.kral.productmanagement.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kral.productmanagement.product.model.Product;
import com.kral.productmanagement.product.model.ProductType;
import com.kral.productmanagement.product.service.ProductService;

@RestController
@RequestMapping("product")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@PostMapping
	public Product newProduct(@RequestBody Product product) {
		return productService.postProduct(product);
	}
	
	@GetMapping("byid/{productId}")
	public Product getById(@PathVariable Integer productId) {
		return productService.productById(productId);
	}
	
	@GetMapping("bytype/{productType")
	public List<Product> getByType(@PathVariable ProductType productType){
		return productService.productsByType(productType);
	}
}
