package com.kral.productmanagement.product.service;

import java.util.List;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.kral.productmanagement.product.model.Product;
import com.kral.productmanagement.product.model.ProductType;
import com.kral.productmanagement.product.repository.ProductRepository;
import com.kral.productmanagement.product.vo.DescriptionVO;
import com.kral.productmanagement.product.vo.ProductVO;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductRepository  productRepository;
	
	@Autowired
	private DescriptionClient client;

	@Override
	public Product productById(Integer productId) {
		return productRepository.findById(productId).orElseThrow();
		 
	}

	@Override
	public List<Product> productsByType(ProductType productType) {
		return productRepository.findByType(productType);
	}

	@Override
	public Product postProduct(@RequestBody Product product) {
		
		return productRepository.save(product);
	}

	@Override
	public ProductVO getProductAndDescriptionById(Integer productId) {
		Optional<Product> option = productRepository.findById(productId);
		
		if(option.isPresent()) {
			Product product = option.get();
			DescriptionVO description = client.getDescription(productId);
			ProductVO pAndD = new ProductVO();
		    pAndD.setProduct(product);
		    pAndD.setProductDescription(description);
		    return pAndD;
			
			}
		return null;
	}
	
	
	
	
}
